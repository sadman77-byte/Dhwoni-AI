# Discord VC Bot – Music Player

A Discord bot that plays music from YouTube in voice channels.

## Features
- `/play <song or URL>` – play music
- `/skip` – skip current song
- `/pause` / `/resume`
- `/stop` – clear queue and leave
- `/queue` – show upcoming songs
- `/volume <0-100>`
- `/leave` – force leave

## Setup
1. Clone and `npm install`
2. Create `.env` with your bot token, client ID, guild ID
3. Install **ffmpeg** globally (see instructions)
4. Run `npm run deploy` to register slash commands
5. Run `npm start` to start the bot

## Requirements
- Node.js v16.9+
- ffmpeg
