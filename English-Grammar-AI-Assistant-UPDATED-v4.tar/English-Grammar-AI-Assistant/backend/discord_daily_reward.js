const { EmbedBuilder } = require('discord.js');

async function checkStreakMilestones(client) {
    const db = require('../database/db.js');
    const stmt = db.prepare(`
        SELECT user_id, streak 
        FROM daily_rewards 
        WHERE streak IN (7, 30, 50, 100, 200, 365)
        AND date(last_claim) = date('now')
    `);
    
    const results = stmt.all();
    
    for (const result of results) {
        const user = await client.users.fetch(result.user_id).catch(() => null);
        if (!user) continue;
        
        const milestoneMessages = {
            7: '🎉 You\'ve reached a 7-day streak!',
            30: '🌟 Amazing! 30-day streak achieved!',
            50: '💪 50 days! You\'re unstoppable!',
            100: '👑 Legendary 100-day streak!',
            200: '🏆 200 days! You\'re a daily reward master!',
            365: '🎊 ONE YEAR STREAK! Incredible dedication!'
        };
        
        const embed = new EmbedBuilder()
            .setColor(0xFFD700)
            .setTitle('🏅 Streak Milestone Unlocked!')
            .setDescription(milestoneMessages[result.streak])
            .addFields({ 
                name: 'Current Streak', 
                value: `🔥 ${result.streak} days`,
                inline: true 
            })
            .setTimestamp();
        
        await user.send({ embeds: [embed] }).catch(() => {});
    }
}

module.exports = { checkStreakMilestones };
