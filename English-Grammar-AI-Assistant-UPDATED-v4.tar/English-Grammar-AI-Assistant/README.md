# English Grammar AI Assistant

This project combines multiple English grammar corpora and various web-based UI prototypes into a unified structure.

## Structure
- `grammar_corpus/`: Contains structured JSON files of grammar rules, linguistics, and communication from various sources including Strunk & White, Helen Sword, Top 50 Mistakes, Bassnett, Krashen, Semiotics, Semantics, Chinese Grammar, Bengali Grammar, Handwritten Notes, Chomsky's Universal Grammar, Language and Mind, English Phonetics and Phonology, Discourse Analysis, and Intercultural Communication.
- `prototypes/`: HTML/CSS/JS UI prototypes (Chat, Verification, Music Player, Dashboard, Calculator).
- `backend/`: Discord bot scripts for daily rewards and music.
